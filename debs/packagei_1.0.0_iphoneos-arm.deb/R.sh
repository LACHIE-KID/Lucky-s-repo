rm Packages
rm Packages.bz2
rm Packages.gz
