#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>
@property (strong, nonatomic) UIWindow *window;
@end

@implementation AppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    
    // Classic iOS 6 dark linen background
    self.window.backgroundColor = [UIColor colorWithRed:0.15 green:0.16 blue:0.18 alpha:1.0];
    
    // Create Root View Controller
    UIViewController *rootVC = [[UIViewController alloc] init];
    rootVC.view.backgroundColor = [UIColor colorWithRed:0.15 green:0.16 blue:0.18 alpha:1.0];
    
    // Add "test 1 2 3" Label
    UILabel *testLabel = [[UILabel alloc] initWithFrame:CGRectMake(20, 200, 280, 50)];
    testLabel.text = @"test 1 2 3";
    testLabel.textColor = [UIColor whiteColor];
    testLabel.textAlignment = NSTextAlignmentCenter;
    testLabel.font = [UIFont boldSystemFontOfSize:28];
    
    // Skeuomorphic text drop shadow
    testLabel.shadowColor = [UIColor blackColor];
    testLabel.shadowOffset = CGSizeMake(0, -1);
    testLabel.backgroundColor = [UIColor clearColor];
    
    [rootVC.view addSubview:testLabel];
    
    self.window.rootViewController = rootVC;
    [self.window makeKeyAndVisible];
    return YES;
}

@end

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
