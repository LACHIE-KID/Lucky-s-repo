#import "RootViewController.h"
#import <QuartzCore/QuartzCore.h>

@implementation RootViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.title = @"Cydia";
    
    // 1. Skeuomorphic Linen Background (iOS 6 Style)
    self.view.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"linen_texture.png"]];
    if (!self.view.backgroundColor) {
        // Fallback dark slate color if texture image isn't loaded yet
        self.view.backgroundColor = [UIColor colorWithRed:0.15 green:0.16 blue:0.18 alpha:1.0];
    }
    
    // 2. Custom Skeuomorphic Navigation Bar Styling
    UINavigationBar *navBar = self.navigationController.navigationBar;
    [navBar setTintColor:[UIColor colorWithRed:0.12 green:0.14 blue:0.18 alpha:1.0]];
    
    // 3. Create Grouped TableView for Featured Packages & Categories
    UITableView *tableView = [[UITableView alloc] initWithFrame:self.view.bounds style:UITableViewStyleGrouped];
    tableView.delegate = self;
    tableView.dataSource = self;
    tableView.backgroundColor = [UIColor clearColor];
    tableView.separatorStyle = UITableViewCellSeparatorStyleSingleLineEtched;
    tableView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    [self.view addSubview:tableView];
}

#pragma mark - Table View Data Source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 3;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (section == 0) return 2; // Featured Banner & Welcome
    if (section == 1) return 3; // Main Categories (Sections, Changes, Search)
    return 2;                   // Storage & About
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
    if (section == 0) return @"WELCOME TO PACKAGEI";
    if (section == 1) return @"CATEGORIES";
    return @"SYSTEM";
}

// Skeuomorphic Custom Section Headers with Gloss Effect
- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    NSString *sectionTitle = [self tableView:tableView titleForHeaderInSection:section];
    if (!sectionTitle) return nil;

    UIView *headerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, tableView.bounds.size.width, 30)];
    headerView.backgroundColor = [UIColor clearColor];

    UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(15, 5, tableView.bounds.size.width - 30, 20)];
    label.text = sectionTitle;
    label.font = [UIFont boldSystemFontOfSize:12];
    label.textColor = [UIColor colorWithWhite:0.8 alpha:1.0];
    label.shadowColor = [UIColor blackColor];
    label.shadowOffset = CGSizeMake(0, -1); // Classic iOS inset shadow
    label.backgroundColor = [UIColor clearColor];
    
    [headerView addSubview:label];
    return headerView;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *CellIdentifier = @"PackageICell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:CellIdentifier];
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
        
        // Skeuomorphic Glossy Highlight
        cell.selectionStyle = UITableViewCellSelectionStyleGray;
    }
    
    if (indexPath.section == 0) {
        if (indexPath.row == 0) {
            cell.textLabel.text = @"Featured Packages";
            cell.detailTextLabel.text = @"Hand-picked tweaks and themes for iOS 6";
            cell.imageView.image = [UIImage imageNamed:@"star_icon.png"];
        } else {
            cell.textLabel.text = @"User Guides & FAQ";
            cell.detailTextLabel.text = @"Learn how to manage sources and deb packages";
            cell.imageView.image = [UIImage imageNamed:@"help_icon.png"];
        }
    } else if (indexPath.section == 1) {
        NSArray *titles = @[@"Sections", @"Changes", @"Search"];
        NSArray *subtitles = @[@"Browse packages by category", @"Recently updated packages", @"Find tweaks by name or developer"];
        
        cell.textLabel.text = titles[indexPath.row];
        cell.detailTextLabel.text = subtitles[indexPath.row];
    } else {
        if (indexPath.row == 0) {
            cell.textLabel.text = @"Storage Information";
            cell.detailTextLabel.text = @"System disk space & partition info";
        } else {
            cell.textLabel.text = @"About PackageI";
            cell.detailTextLabel.text = @"Version 1.0.0 (Skeuomorphic Build)";
        }
    }
    
    return cell;
}

@end
